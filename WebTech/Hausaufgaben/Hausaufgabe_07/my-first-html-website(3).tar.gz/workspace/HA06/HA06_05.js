var A = [0,1,2,3,4,5,6,7,8,9]

//reduce
    //reduziert array in dem es die ersten beiden eintraege zusammen fasst
    var B = A.reduce(function(sum,num){return sum+num})
    
//map 
    //applies function to each entrie, result : new array
    var C = A.map(function(num){return num + 2})
    
//filter
    var E = A.filter(function(num){return num> 5})
    
//every
    var F = A.every(function(num){return num<10})
    
//some
    var G = A.some(function(num){return num>5})

//find
    var H = A.find(function(num){return num>5})


console.log(A)
console.log(B)
console.log(C)
//forEach
    var D = A.forEach(function(element) {console.log(element);});
console.log(E)
console.log(F)
console.log(G)
console.log(H)
console.log([1,4,5,2].sort())
